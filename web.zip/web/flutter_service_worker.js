'use strict';
const MANIFEST = 'flutter-app-manifest';
const TEMP = 'flutter-temp-cache';
const CACHE_NAME = 'flutter-app-cache';

const RESOURCES = {"flutter_bootstrap.js": "0691cdc2b397d4a58dbacac51cf5e3c0",
"version.json": "48707032fe4e0b43706f6c965604676f",
"splash/img/light-2x.png": "c9cb49f777ca89a6691cbfec22804c8a",
"splash/img/dark-4x.png": "5d75352041c29fd76a32fe0253ca281b",
"splash/img/light-3x.png": "7582ca3184e071858655f5198c158279",
"splash/img/dark-3x.png": "7582ca3184e071858655f5198c158279",
"splash/img/light-4x.png": "5d75352041c29fd76a32fe0253ca281b",
"splash/img/dark-2x.png": "c9cb49f777ca89a6691cbfec22804c8a",
"splash/img/dark-1x.png": "024535a18332396e823bba52bdf031d2",
"splash/img/light-1x.png": "024535a18332396e823bba52bdf031d2",
"index.html": "821d1aa18929e4bb72196b12ea0dc471",
"/": "821d1aa18929e4bb72196b12ea0dc471",
"main.dart.js": "d90b90aa3d95d22acb4fd6d1c4c14b31",
"flutter.js": "888483df48293866f9f41d3d9274a779",
"README.md": "98d56c60becf29dc9bb720e11d535ee7",
"favicon.png": "715e0d6f57e7060676d1e7066b13b833",
"icons/Icon-192.png": "54017f62543e130e44e2d0eabeecc53e",
"icons/Icon-maskable-192.png": "54017f62543e130e44e2d0eabeecc53e",
"icons/Icon-maskable-512.png": "676db8983cba49e15716748ae6b61d09",
"icons/Icon-512.png": "676db8983cba49e15716748ae6b61d09",
"manifest.json": "dd8fff3fa0af70927d7b63de8b938012",
"main.dart.js_1.part.js": "0ebd2b823294c5f1eef67c74425ab1ab",
".git/config": "53298df73a0c0028ddda0ca0c86df386",
".git/objects/33/0d20ea71d6b5b05b06618ea1aabbd1070debcd": "5fb08fe9dafe72a3a38e4eae21b25cff",
".git/objects/bc/aa14d1b8f5f01934f9d816690df09086f1e0a3": "08011b72018d087d5c3048c6c9c40e47",
".git/objects/88/7c3897767b53d9a6bb217001479b0ba452970b": "b19e296be1241521550e037aae72aee6",
".git/HEAD": "cf7dd3ce51958c5f13fece957cc417fb",
".git/info/exclude": "036208b4a1ab4a235d75c181e685e5a3",
".git/logs/HEAD": "9ed389ea192426c254fc10e47ed4058e",
".git/logs/refs/heads/main": "3ee69d451867a97a3c14b165452c9ca2",
".git/description": "a0a7c3fff21f2aea3cfa1d0316dd816c",
".git/hooks/commit-msg.sample": "579a3c1e12a1e74a98169175fb913012",
".git/hooks/pre-rebase.sample": "56e45f2bcbc8226d2b4200f7c46371bf",
".git/hooks/sendemail-validate.sample": "4d67df3a8d5c98cb8565c07e42be0b04",
".git/hooks/pre-commit.sample": "5029bfab85b1c39281aa9697379ea444",
".git/hooks/applypatch-msg.sample": "ce562e08d8098926a3862fc6e7905199",
".git/hooks/fsmonitor-watchman.sample": "a0b2633a2c8e97501610bd3f73da66fc",
".git/hooks/pre-receive.sample": "2ad18ec82c20af7b5926ed9cea6aeedd",
".git/hooks/prepare-commit-msg.sample": "2b5c047bdb474555e1787db32b2d2fc5",
".git/hooks/post-update.sample": "2b7ea5cee3c49ff53d41e00785eb974c",
".git/hooks/pre-merge-commit.sample": "39cb268e2a85d436b9eb6f47614c3cbc",
".git/hooks/pre-applypatch.sample": "054f9ffb8bfe04a599751cc757226dda",
".git/hooks/pre-push.sample": "2c642152299a94e05ea26eae11993b13",
".git/hooks/update.sample": "647ae13c682f7827c22f5fc08a03674e",
".git/hooks/push-to-checkout.sample": "c7ab00c7784efeadad3ae9b228d4b4db",
".git/refs/heads/main": "4ec9befe56f00f253352951205cb5617",
".git/index": "6c9d5ffac185ef73ee79e824721d6f89",
".git/COMMIT_EDITMSG": "a8297d555dd34879e8e48e1cf12acefa",
"assets/AssetManifest.json": "52f9230fac49e567e3af88071b1e7c62",
"assets/NOTICES": "8ed57f768f1bf166fda4a5b31c3dab2c",
"assets/FontManifest.json": "153e9399e990897d5887f86f7747faa6",
"assets/AssetManifest.bin.json": "c33c1d478e66e6e5f7deb288b6249b18",
"assets/packages/font_awesome_flutter/lib/fonts/fa-solid-900.ttf": "78aa755343a1718dfa785175965c3af0",
"assets/packages/font_awesome_flutter/lib/fonts/fa-regular-400.ttf": "262525e2081311609d1fdab966c82bfc",
"assets/packages/font_awesome_flutter/lib/fonts/fa-brands-400.ttf": "15d54d142da2f2d6f2e90ed1d55121af",
"assets/packages/iconsax_flutter/fonts/FlutterIconsax.ttf": "6ebc7bc5b74956596611c6774d8beb5b",
"assets/shaders/ink_sparkle.frag": "ecc85a2e95f5e9f53123dcaf8cb9b6ce",
"assets/AssetManifest.bin": "91eeeb6bb4c5739f53f9a7e4868fad42",
"assets/fonts/MaterialIcons-Regular.otf": "fd4e193c07d155db7a11001bda1fba60",
"assets/assets/svg/riyal-symbol-icon.svg": "267983bd84fbbb0bc83090691eaf5a5a",
"assets/assets/svg/access-denied.svg": "dac1f98555ef3837c11d3716505800da",
"assets/assets/svg/manual_boarding.svg": "1043fee318b588482c4d49713a4ca0de",
"assets/assets/svg/shift-report-icon.svg": "69e2b8cccbd906a8c6ca508829a12d97",
"assets/assets/svg/logout.svg": "299e889c97b9e84f458a4fb888a9250f",
"assets/assets/svg/change-language.svg": "b53f119efd18d1d3abe29d01723fd848",
"assets/assets/svg/boarding-pass-scan-icon.svg": "046663f355c56b8da93143a9162a3799",
"assets/assets/svg/vip-room-icon.svg": "a8f55e3fe954f57cb052f15b509b2108",
"assets/assets/svg/change-language-icon.svg": "b55a9af755d5321431b4248cf284ae7e",
"assets/assets/svg/qatar-airways-logo.svg": "56df04df9bc3dfde07666862894720dd",
"assets/assets/svg/access-expired-icon.svg": "0c40dc065a087358e885dfc17af81747",
"assets/assets/svg/change-lounge-icon.svg": "9a74a7755b1122c85b789c98d96fc883",
"assets/assets/svg/status_icon.svg": "eec84b186871c7e7207fa4e2e804ac72",
"assets/assets/svg/bin-icon.svg": "ec1b8860ea20a035cf8ab2b589288e1a",
"assets/assets/svg/settings.svg": "3acc2c4c21184c838281224512a238f6",
"assets/assets/svg/mute-icon.svg": "3cc8d01a26ea4758af15fff04abcf660",
"assets/assets/svg/note.svg": "e0143b95a737add73607fe7b68465f83",
"assets/assets/svg/twofactor.svg": "12c387a2e08e05030068c7c3166ea52e",
"assets/assets/svg/external_link.svg": "39ca8de60a335d4f32da9b9c526472d3",
"assets/assets/svg/sleep-cabin-icon.svg": "7342c6f6538bbf4e535826f527198b52",
"assets/assets/svg/add_image.svg": "a65a6f277c368f93196d74a3e9cf7356",
"assets/assets/svg/logout2.svg": "decaffa99c41f305b7d6e2344ceefaf9",
"assets/assets/svg/shower-amenities-icon.svg": "bd75a04b83dcc7ef2a1fde7a2278c6c8",
"assets/assets/svg/close-session-icon.svg": "664ce17ef52684d7313d3f3f39144b33",
"assets/assets/svg/document-icon.svg": "90aa6026a6250761df6cefe3859ef4c7",
"assets/assets/svg/eligibility/eligible.svg": "b112e8c7a55adb52aefe11dc9a75e2bb",
"assets/assets/svg/eligibility/expired.svg": "ec94b1722d5189a46ded28fc5df8a310",
"assets/assets/svg/eligibility/valid.svg": "f745226cd7c0a9dd3fe5d12c39c1137b",
"assets/assets/svg/eligibility/not_eligible.svg": "490135ebd9bfbd342e4ce5e10baaa203",
"assets/assets/svg/otp-icon.svg": "f58338d623996d9ff0a1b2560000e4f6",
"assets/assets/svg/refresh.svg": "271833a72e79d0978d0c5ae37bfe1ee5",
"assets/assets/svg/sound-icon.svg": "eaf44537c27dd023668eb1a675e70b2b",
"assets/assets/svg/check_mark.svg": "d6c6e2fb3c754a0b8768e920fc96b832",
"assets/assets/svg/camera.svg": "94170bab97eeb7652c67e264132faae4",
"assets/assets/svg/hayyak-lounge-icon.svg": "da8d9bdffa3d4928384ce22463297520",
"assets/assets/svg/boarding-scan-area.svg": "84d4925f40cf8b9136917c08479b10e0",
"assets/assets/svg/Highest.svg": "eaf44537c27dd023668eb1a675e70b2b",
"assets/assets/svg/lounge-membership-icon.svg": "e338f04a5608130abb48df44dd002e1a",
"assets/assets/svg/cash-icon.svg": "0ed4798150bf76ab8fcc6620fc5147bf",
"assets/assets/svg/scan-icon.svg": "fa314766f9b080eb76ca1437661735bc",
"assets/assets/svg/filter.svg": "f8036c5aec8f16a76d2820490b1f0191",
"assets/assets/svg/scan-boarding-icon.svg": "487ce292cbed13ecb66c8d61e4b1b0f8",
"assets/assets/svg/voucher-coupon-icon.svg": "c65c2c3a812d0190bc7b76d0389ebd6f",
"assets/assets/svg/password.svg": "31b1994ce7bf6a1bd988b8d5b7bc27ee",
"assets/assets/svg/partner-access-icon.svg": "91b08d36df612f649f24216272d1027c",
"assets/assets/svg/access-valid-icon.svg": "aee64663fc6e89d629ca9c98557b760f",
"assets/assets/svg/ticket-icon.svg": "57bc5ab7d4c4bafdbd17b97b49a21238",
"assets/assets/svg/vip-family-icon.svg": "26e07ba3bfdddbf88353ade4c0bccad3",
"assets/assets/svg/eligible-to-choose-icon.svg": "e195486194a74d7eccd908930b07726e",
"assets/assets/images/nahdi_image.png": "e277d4ad9315eb0e81beba28076cda68",
"assets/assets/images/successfully_done.gif": "e31434f44edc73715cca56624a8e2374",
"assets/assets/images/akcc-logo.svg": "717eb3880cef7d5659c6662b9746c0e5",
"assets/assets/images/platinum_tier.png": "90ffdcc5a5e8f772a7732db5a8f242da",
"assets/assets/images/royal_ceremonies.png": "0b6ab51bb33069e2c6fe662ddd7686f9",
"assets/assets/images/riyal-symbol.svg": "8ffea0488abbe494e8a3db35953f9744",
"assets/assets/images/dragon_pass.png": "20d04892600fa1d03a878edda321dc52",
"assets/assets/images/login_image.png": "976afe59940622508f5dedc89532f98d",
"assets/assets/images/qatar-airways-logo.png": "b6b02413aa316806cc899a3e569214ef",
"assets/assets/images/logo_back.png": "edb88894ba235733bfa5adc8c14ce65c",
"assets/assets/images/qatar_logo.png": "94b47a3c2c854d226081e1b5d232588e",
"assets/assets/images/lounge_key.png": "567d04ed7b892f33733a898bd8414205",
"assets/assets/images/error-icon.svg": "fe5549ca3187c363a51db0f15d92423c",
"assets/assets/images/riyal-symbol-icon.png": "ccf3b2620efc41844a8cf2a9e177804b",
"assets/assets/images/sliver_tier.png": "e392551fe79f07466a7afe33f72d54ac",
"assets/assets/images/saudi_investment.png": "2c415fd750d385d5a007d1c1a83bf968",
"assets/assets/images/logo.png": "1f6036472f30f8f44228180604778348",
"assets/assets/images/proierity_pass.png": "8d3117bbf474d5e42b225e09962d0c56",
"assets/assets/images/voucher.png": "01b1ec38084950adde4d75ed93af4535",
"assets/assets/images/app_logo.png": "6cc4639cc54de413758e45dba567c7d5",
"assets/assets/images/burgundy_tier.png": "6857d282631505dfa41956cffd80e59b",
"assets/assets/images/alrajhi.png": "7cbee8ee6c5e1313c609b1fed497086f",
"assets/assets/images/partner_access.png": "f471757277952108a2a1749675dd173e",
"assets/assets/images/gold_tier.png": "d60c5ccc89ef980456d39025f452f3e8",
"assets/assets/images/cash_payment.png": "f6b25a084c35b5f7833c96372e577917",
"assets/assets/images/lounge_membership.png": "050dc16840730f8fb513d570ac633b52",
"assets/assets/icons/delete_icon.svg": "61a7352ff927ef00f4bc7fc93ec9ed36",
"assets/assets/icons/solid_airplane_icon_b.svg": "a1d2c596664b89ab7853340a7f56fae1",
"assets/assets/icons/scan_icon.svg": "64e2c8cbd66b1dd945c210af33192431",
"assets/assets/icons/solid_airplane_icon_c.svg": "6054f2e7a6c8200560b0909f60552af1",
"assets/assets/icons/solid_logout_icon.svg": "040945d66134769e1d2fa1fb5fb2c9fd",
"assets/assets/icons/seat_icon.svg": "6b11eb0eb186f5fb1d3f534162866aa9",
"assets/assets/icons/solid_language_icon.svg": "7d3fb51842fd9850dc81e9ff36b444d3",
"assets/assets/icons/list_icon.svg": "11675cc54a31488eb35f81ae4cd4cc08",
"assets/assets/icons/solid_people_icon.svg": "9a6feb060a595696e0c36a1e4148a656",
"assets/assets/icons/hayyak-lounge-icon.png": "8571ee000c260ea858661be4e970cc76",
"assets/assets/fonts/tajwal/Tajawal-Regular.ttf": "e3fe295c55a0cb720f766bccc5eecf63",
"assets/assets/fonts/en/InterMedium.ttf": "8540f35bf8acd509b9ce356f1111e983",
"assets/assets/fonts/en/InterLight.ttf": "dfaec8b8820224135d07f1b409ceb214",
"assets/assets/fonts/en/InterSemiBold.ttf": "e5532d993e2de30fa92422df0a8849dd",
"assets/assets/fonts/en/InterRegular.ttf": "37dcabff629c3690303739be2e0b3524",
"assets/assets/fonts/en/InterExtraLight.ttf": "2c6c78d98816958b53fea58451f921d3",
"assets/assets/fonts/en/InterThin.ttf": "6f2d2f41f504aee66da88684f15d7e1d",
"assets/assets/fonts/en/InterExtraBold.ttf": "a6ed481bff60bc9270904d214947ab13",
"assets/assets/fonts/en/InterBold.ttf": "7ef6f6d68c7fedc103180f2254985e8c",
"assets/assets/fonts/en/InterBlack.ttf": "b797a429ef21b9b7d44b96038cdb10f2",
"assets/assets/fonts/poppins/Poppins-Medium.ttf": "bf59c687bc6d3a70204d3944082c5cc0",
"assets/assets/fonts/poppins/Poppins-Regular.ttf": "093ee89be9ede30383f39a899c485a82",
"assets/assets/fonts/poppins/Poppins-Bold.ttf": "08c20a487911694291bd8c5de41315ad",
"assets/assets/fonts/poppins/Poppins-SemiBold.ttf": "6f1520d107205975713ba09df778f93f",
"assets/assets/sound/scanner_beep.mp3": "ae2aab1a1b773f3f3ef7e1637aa6e0e4",
"canvaskit/skwasm.js": "1ef3ea3a0fec4569e5d531da25f34095",
"canvaskit/skwasm_heavy.js": "413f5b2b2d9345f37de148e2544f584f",
"canvaskit/skwasm.js.symbols": "0088242d10d7e7d6d2649d1fe1bda7c1",
"canvaskit/canvaskit.js.symbols": "58832fbed59e00d2190aa295c4d70360",
"canvaskit/skwasm_heavy.js.symbols": "3c01ec03b5de6d62c34e17014d1decd3",
"canvaskit/skwasm.wasm": "264db41426307cfc7fa44b95a7772109",
"canvaskit/chromium/canvaskit.js.symbols": "193deaca1a1424049326d4a91ad1d88d",
"canvaskit/chromium/canvaskit.js": "5e27aae346eee469027c80af0751d53d",
"canvaskit/chromium/canvaskit.wasm": "24c77e750a7fa6d474198905249ff506",
"canvaskit/canvaskit.js": "140ccb7d34d0a55065fbd422b843add6",
"canvaskit/canvaskit.wasm": "07b9f5853202304d3b0749d9306573cc",
"canvaskit/skwasm_heavy.wasm": "8034ad26ba2485dab2fd49bdd786837b"};
// The application shell files that are downloaded before a service worker can
// start.
const CORE = ["main.dart.js",
"index.html",
"flutter_bootstrap.js",
"assets/AssetManifest.bin.json",
"assets/FontManifest.json"];

// During install, the TEMP cache is populated with the application shell files.
self.addEventListener("install", (event) => {
  self.skipWaiting();
  return event.waitUntil(
    caches.open(TEMP).then((cache) => {
      return cache.addAll(
        CORE.map((value) => new Request(value, {'cache': 'reload'})));
    })
  );
});
// During activate, the cache is populated with the temp files downloaded in
// install. If this service worker is upgrading from one with a saved
// MANIFEST, then use this to retain unchanged resource files.
self.addEventListener("activate", function(event) {
  return event.waitUntil(async function() {
    try {
      var contentCache = await caches.open(CACHE_NAME);
      var tempCache = await caches.open(TEMP);
      var manifestCache = await caches.open(MANIFEST);
      var manifest = await manifestCache.match('manifest');
      // When there is no prior manifest, clear the entire cache.
      if (!manifest) {
        await caches.delete(CACHE_NAME);
        contentCache = await caches.open(CACHE_NAME);
        for (var request of await tempCache.keys()) {
          var response = await tempCache.match(request);
          await contentCache.put(request, response);
        }
        await caches.delete(TEMP);
        // Save the manifest to make future upgrades efficient.
        await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
        // Claim client to enable caching on first launch
        self.clients.claim();
        return;
      }
      var oldManifest = await manifest.json();
      var origin = self.location.origin;
      for (var request of await contentCache.keys()) {
        var key = request.url.substring(origin.length + 1);
        if (key == "") {
          key = "/";
        }
        // If a resource from the old manifest is not in the new cache, or if
        // the MD5 sum has changed, delete it. Otherwise the resource is left
        // in the cache and can be reused by the new service worker.
        if (!RESOURCES[key] || RESOURCES[key] != oldManifest[key]) {
          await contentCache.delete(request);
        }
      }
      // Populate the cache with the app shell TEMP files, potentially overwriting
      // cache files preserved above.
      for (var request of await tempCache.keys()) {
        var response = await tempCache.match(request);
        await contentCache.put(request, response);
      }
      await caches.delete(TEMP);
      // Save the manifest to make future upgrades efficient.
      await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
      // Claim client to enable caching on first launch
      self.clients.claim();
      return;
    } catch (err) {
      // On an unhandled exception the state of the cache cannot be guaranteed.
      console.error('Failed to upgrade service worker: ' + err);
      await caches.delete(CACHE_NAME);
      await caches.delete(TEMP);
      await caches.delete(MANIFEST);
    }
  }());
});
// The fetch handler redirects requests for RESOURCE files to the service
// worker cache.
self.addEventListener("fetch", (event) => {
  if (event.request.method !== 'GET') {
    return;
  }
  var origin = self.location.origin;
  var key = event.request.url.substring(origin.length + 1);
  // Redirect URLs to the index.html
  if (key.indexOf('?v=') != -1) {
    key = key.split('?v=')[0];
  }
  if (event.request.url == origin || event.request.url.startsWith(origin + '/#') || key == '') {
    key = '/';
  }
  // If the URL is not the RESOURCE list then return to signal that the
  // browser should take over.
  if (!RESOURCES[key]) {
    return;
  }
  // If the URL is the index.html, perform an online-first request.
  if (key == '/') {
    return onlineFirst(event);
  }
  event.respondWith(caches.open(CACHE_NAME)
    .then((cache) =>  {
      return cache.match(event.request).then((response) => {
        // Either respond with the cached resource, or perform a fetch and
        // lazily populate the cache only if the resource was successfully fetched.
        return response || fetch(event.request).then((response) => {
          if (response && Boolean(response.ok)) {
            cache.put(event.request, response.clone());
          }
          return response;
        });
      })
    })
  );
});
self.addEventListener('message', (event) => {
  // SkipWaiting can be used to immediately activate a waiting service worker.
  // This will also require a page refresh triggered by the main worker.
  if (event.data === 'skipWaiting') {
    self.skipWaiting();
    return;
  }
  if (event.data === 'downloadOffline') {
    downloadOffline();
    return;
  }
});
// Download offline will check the RESOURCES for all files not in the cache
// and populate them.
async function downloadOffline() {
  var resources = [];
  var contentCache = await caches.open(CACHE_NAME);
  var currentContent = {};
  for (var request of await contentCache.keys()) {
    var key = request.url.substring(origin.length + 1);
    if (key == "") {
      key = "/";
    }
    currentContent[key] = true;
  }
  for (var resourceKey of Object.keys(RESOURCES)) {
    if (!currentContent[resourceKey]) {
      resources.push(resourceKey);
    }
  }
  return contentCache.addAll(resources);
}
// Attempt to download the resource online before falling back to
// the offline cache.
function onlineFirst(event) {
  return event.respondWith(
    fetch(event.request).then((response) => {
      return caches.open(CACHE_NAME).then((cache) => {
        cache.put(event.request, response.clone());
        return response;
      });
    }).catch((error) => {
      return caches.open(CACHE_NAME).then((cache) => {
        return cache.match(event.request).then((response) => {
          if (response != null) {
            return response;
          }
          throw error;
        });
      });
    })
  );
}
